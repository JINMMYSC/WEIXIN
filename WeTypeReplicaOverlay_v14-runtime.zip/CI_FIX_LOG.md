# CI repair log

## Baseline

- Source: `WeTypeReplicaOverlay_v14.zip`, supplied by the user on 2026-09-13.
- Pre-CI evidence inherited from V14: 87 Core tests, 121 parsed Swift files, and 10 plist/entitlement files.
- Existing Mac validation gap: `XcodeIntegration/validate_on_mac.sh` omitted `WeTypeReplicaVoiceActivity` and did not produce a device build or IPA.

## CI changes before the first run

- Added one repeatable Mac entry point that runs Core tests, XcodeGen, all five simulator schemes, an unsigned device build, IPA packaging, SHA-256 reporting, and embedded-extension listing.
- Added a GitHub Actions workflow on `macos-15` with unconditional complete-log upload and successful-build IPA/app upload.
- Added `WeTypeReplicaVoiceActivity` to the existing Mac validation matrix.
- Replaced the inherited `ios-build.yml`, which omitted Voice Activity and artifact packaging, with the complete unsigned workflow so pushes do not start two competing build matrices.

## Real Xcode runs

### Run 1 — failed before compilation

- Run: `34745214999`
- Error: `env: bash\r: No such file or directory` while launching `XcodeIntegration/ci_unsigned_build.sh`.
- Root cause: the V14 archive was prepared on Windows without a Git attributes policy, so shell scripts reached the macOS runner with CRLF line endings.
- Fix: enforce LF for shell scripts and other source/config text through `.gitattributes`; verify the staged shell-script bytes before creating each CI archive.
